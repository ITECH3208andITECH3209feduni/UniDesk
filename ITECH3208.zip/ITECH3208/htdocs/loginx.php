<?
    $studentID = $_POST['studentID'];
    $email = $_POST['email'];
    
    
    //Database Connection

  $conn = mysqli_connect("sql203.epizy.com", "epiz_32713233", "tphx042m", "epiz_32713233_unidesk");

   // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

 // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO login_table VALUES ('$studentID','$email') ";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>Logged in successfully.";

        } else{
            echo "ERROR: Wrong login info $sql. "
                . mysqli_error($conn);
        }
         
        // Close connection
        mysqli_close($conn);
        ?>