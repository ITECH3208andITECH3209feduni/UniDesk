<?
    $studentID = $_POST['studentID'];
    $email = $_POST['email'];
    
    //Database Connection

  $conn = mysqli_connect("sql203.epizy.com", "epiz_32713233", "tphx042m", "epiz_32713233_unidesk");

   // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

 // Performing insert query execution
        // here our table name is college
        if(isset(['studentID'])){
            
            $studentID = $_POST['studentID'];
            $email = $_POST['email'];
            
            $sql = "SELECT * FROM Student_Registration WHERE studentID = '$studentID' AND email = '$email'"
        }
         
        $result = mysqli_query($conn, $sql)
        if(mysqli_num_rows($result) == 1)
        {
            session_start();
            $_SESSION['epiz_32713233_unidesk'] = 'true';
            echo 'logged in';
        }
        else
        {
            echo 'Wrong email or studentID';
        }
        // Close connection
        mysqli_close($conn);
        ?>