<?
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $studentID = $_POST['studentID'];
    $email = $_POST['email'];
    $country_code = $_POST['country_code'];
    $phone = $_POST['phone'];
    $subject = $_POST['subject'];
    $assignment_done = $_POST['assignment_done'];
    
    //Database Connection

  $conn = mysqli_connect("sql203.epizy.com", "epiz_32713233", "tphx042m", "epiz_32713233_unidesk");

   // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

 // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO Student_Registration VALUES ('$first_name','$last_name','$studentID','$email','$country_code','$phone','$subject','$assignment_done') ";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully.";

        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
         
        // Close connection
        mysqli_close($conn);
        ?>